package errs

import "net/http"

type MessageErr interface {
	Error() string
	Message() string
	Status() int
}

type MessageErrData struct {
	ErrMessage string `json:"message"`
	StatusCode int    `json:"statusCode"`
	Err        string `json:"error"`
}

func (m MessageErrData) Status() int {
	return m.StatusCode
}

func (m MessageErrData) Message() string {
	return m.ErrMessage
}

func (m MessageErrData) Error() string {
	return m.Err
}

func NewBadRequestError(message string) MessageErr {
	return MessageErrData{
		StatusCode: http.StatusBadRequest,
		Err:        "BAD_REQUEST",
		ErrMessage: message,
	}
}

func NewUnprocessibleEntityError(message string) MessageErr {
	return MessageErrData{
		StatusCode: http.StatusUnprocessableEntity,
		Err:        "INVALID_REQUEST_BODY",
		ErrMessage: message,
	}
}

func NewNotFoundError(message string) MessageErr {
	return MessageErrData{
		StatusCode: http.StatusNotFound,
		Err:        "NOT_FOUND",
		ErrMessage: message,
	}
}

func NewInternalServerError(message string) MessageErr {
	return MessageErrData{
		StatusCode: http.StatusInternalServerError,
		Err:        "INTERNAL_SERVER_ERROR",
		ErrMessage: message,
	}
}
