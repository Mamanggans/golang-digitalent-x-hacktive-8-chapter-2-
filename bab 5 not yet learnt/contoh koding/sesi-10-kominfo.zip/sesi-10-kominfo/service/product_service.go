package service

import (
	"net/http"
	"sesi-10-kominfo/dto"
	"sesi-10-kominfo/entity"
	"sesi-10-kominfo/pkg/errs"
	"sesi-10-kominfo/repository/product_repo"
)

type ProductService interface {
	CreateProduct(newProductRequest dto.NewProductRequest) (*dto.NewProductResponse, errs.MessageErr)
	GetProducts() (*dto.ProductsResultResponse, errs.MessageErr)
}

type productService struct {
	productRepo product_repo.ProductRepo
}

func NewProductService(productRepo product_repo.ProductRepo) ProductService {
	return &productService{
		productRepo: productRepo,
	}
}

func (p *productService) GetProducts() (*dto.ProductsResultResponse, errs.MessageErr) {
	products, err := p.productRepo.GetProducts()

	if err != nil {
		return nil, err
	}

	var productsResponse []dto.ProductResponse

	for _, eachProdcuts := range products {
		productsResponse = append(productsResponse, eachProdcuts.ProductEntityToDto())
	}

	result := dto.ProductsResultResponse{
		Result:     "success",
		Messsage:   "product data successfully sent",
		Data:       productsResponse,
		StatusCode: http.StatusOK,
	}

	return &result, nil
}

func (p *productService) CreateProduct(newProductRequest dto.NewProductRequest) (*dto.NewProductResponse, errs.MessageErr) {
	productPayload := entity.Product{
		Title:       newProductRequest.Title,
		Description: newProductRequest.Description,
		Stock:       newProductRequest.Stock,
		Price:       newProductRequest.Price,
	}

	newProduct, err := p.productRepo.CreateProduct(productPayload)

	if err != nil {
		return nil, err
	}

	response := dto.NewProductResponse{
		Result:     "success",
		StatusCode: http.StatusCreated,
		Messsage:   "product data successfully created",
		Data: dto.ProductResponse{
			Id:          newProduct.Id,
			Title:       newProduct.Title,
			Description: newProduct.Description,
			Price:       newProduct.Price,
			Stock:       newProduct.Stock,
			CreatedAt:   newProduct.CreatedAt,
		},
	}

	return &response, nil
}
