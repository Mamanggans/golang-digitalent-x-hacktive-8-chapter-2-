package main

import "sesi-10-kominfo/handler"

func main() {
	handler.StartApp()
}
