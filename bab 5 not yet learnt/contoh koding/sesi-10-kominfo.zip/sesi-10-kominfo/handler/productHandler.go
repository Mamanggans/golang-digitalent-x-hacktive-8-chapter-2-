package handler

import (
	"sesi-10-kominfo/dto"
	"sesi-10-kominfo/pkg/errs"
	"sesi-10-kominfo/service"

	"github.com/gin-gonic/gin"
)

type productHandler struct {
	productService service.ProductService
}

func NewProductHandler(productService service.ProductService) *productHandler {
	return &productHandler{
		productService: productService,
	}
}

// CreateNewProduct godoc
// @Tags products
// @Description Create New Product Data
// @ID create-new-product
// @Accept json
// @Produce json
// @Param RequestBody body dto.NewProductRequest true "request body json"
// @Success 201 {object} dto.NewProductResponse
// @Router /products [post]
func (ph *productHandler) CreateProduct(c *gin.Context) {
	var newProductRequest dto.NewProductRequest

	if err := c.ShouldBindJSON(&newProductRequest); err != nil {
		invalidRequestBodyError := errs.NewUnprocessibleEntityError("invalid request body")
		c.JSON(invalidRequestBodyError.Status(), invalidRequestBodyError)
		return
	}

	response, err := ph.productService.CreateProduct(newProductRequest)

	if err != nil {
		c.JSON(err.Status(), err)
		return
	}

	c.JSON(response.StatusCode, response)
}

// GetProducts godoc
// @Tags products
// @Description Get All Product Data
// @ID get-products
// @Produce json
// @Success 200 {object} dto.ProductsResultResponse
// @Router /products [get]
func (ph *productHandler) GetProducts(c *gin.Context) {
	products, err := ph.productService.GetProducts()

	if err != nil {
		c.JSON(err.Status(), err)
		return
	}

	c.JSON(products.StatusCode, products)
}
