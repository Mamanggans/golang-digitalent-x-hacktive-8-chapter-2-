package handler

import (
	"sesi-10-kominfo/database"
	"sesi-10-kominfo/docs"
	"sesi-10-kominfo/repository/product_repo/product_pg"
	"sesi-10-kominfo/service"

	"github.com/gin-gonic/gin"
	swaggerfiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger" // gin-swagger middleware
	// swagger embed files
)

func StartApp() {
	database.InitializeDatabase()

	db := database.GetDbInstance()

	productRepo := product_pg.NewProductPG(db)

	productService := service.NewProductService(productRepo)

	productHandler := NewProductHandler(productService)

	route := gin.Default()

	docs.SwaggerInfo.BasePath = "/"
	docs.SwaggerInfo.Title = "Product API"
	docs.SwaggerInfo.Schemes = []string{"http"}
	docs.SwaggerInfo.Version = "1.0"
	docs.SwaggerInfo.Host = "localhost:3000"

	route.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerfiles.Handler))

	productRoutes := route.Group("/products")
	{
		productRoutes.GET("/", productHandler.GetProducts)
		productRoutes.POST("/", productHandler.CreateProduct)
	}

	route.Run(":3000")
}
