package entity

import (
	"sesi-10-kominfo/dto"
	"time"
)

type Product struct {
	Id          int
	Title       string
	Price       int
	Description string
	Stock       int
	CreatedAt   time.Time
	UpdatedAt   time.Time
}

func (p *Product) ProductEntityToDto() dto.ProductResponse {
	return dto.ProductResponse{
		Id:          p.Id,
		Title:       p.Title,
		Description: p.Description,
		Price:       p.Price,
		Stock:       p.Stock,
		CreatedAt:   p.CreatedAt,
	}
}
