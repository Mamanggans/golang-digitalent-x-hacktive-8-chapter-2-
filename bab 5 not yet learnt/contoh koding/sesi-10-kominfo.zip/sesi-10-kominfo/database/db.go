package database

import (
	"database/sql"
	"fmt"
	"log"

	_ "github.com/lib/pq"
)

const (
	host     = "localhost"
	user     = "airelljordan"
	password = "postgres"
	port     = 5432
	dbname   = "h8-products"
	dialect  = "postgres"
)

var (
	db  *sql.DB
	err error
)

func handleMigration() {
	createProductsTableQuery := `
		CREATE TABLE IF NOT EXISTS "products" (
			"id" SERIAL PRIMARY KEY,
			"title" varchar(255) NOT NULL,
			"price" int NOT NULL,
			"description" TEXT NOT NULL,
			"stock" int NOT NULL,
			"createdAt" timestamptz DEFAULT now(),
			"updatedAt" timestamptz DEFAULT now()
		);
	
	`

	_, err = db.Exec(createProductsTableQuery)

	if err != nil {
		log.Panicf("error while creating required tables: %s\n", err.Error())
	}
}

func handleDbConnection() {
	psqlInfo := fmt.Sprintf("host=%s user=%s password=%s port=%d dbname=%s sslmode=disable", host, user, password, port, dbname)

	db, err = sql.Open(dialect, psqlInfo)

	if err != nil {
		log.Panicf("error while validating db arguments: %s\n", err.Error())
	}

	err = db.Ping()

	if err != nil {
		log.Panicf("error while opening a connection to database: %s\n", err.Error())
	}
}

func InitializeDatabase() {
	handleDbConnection()
	handleMigration()
}

func GetDbInstance() *sql.DB {
	return db
}
