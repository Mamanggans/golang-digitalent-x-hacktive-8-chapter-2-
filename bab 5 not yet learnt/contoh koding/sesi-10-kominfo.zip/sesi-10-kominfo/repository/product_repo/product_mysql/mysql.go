package product_mysql

import (
	"sesi-10-kominfo/entity"
	"sesi-10-kominfo/pkg/errs"
	"sesi-10-kominfo/repository/product_repo"
	"time"
)

type productMysql struct{}

func NewProductMysql() product_repo.ProductRepo {
	return &productMysql{}
}

func (p *productMysql) GetProducts() ([]*entity.Product, errs.MessageErr)

func (p *productMysql) CreateProduct(newProduct entity.Product) (*entity.Product, errs.MessageErr) {
	product := entity.Product{
		Id:          300,
		Title:       "Product Dari MySql",
		Price:       25000,
		Description: "ini adalah product dari msyql",
		Stock:       10,
		CreatedAt:   time.Now(),
	}

	return &product, nil
}
