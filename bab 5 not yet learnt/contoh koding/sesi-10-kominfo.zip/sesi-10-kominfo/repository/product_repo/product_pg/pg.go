package product_pg

import (
	"database/sql"
	"sesi-10-kominfo/entity"
	"sesi-10-kominfo/pkg/errs"
	"sesi-10-kominfo/repository/product_repo"
)

const (
	createProductQuery = `
		INSERT INTO "products"
		(
			title,
			price,
			description,
			stock
		)
		VALUES($1, $2, $3, $4)
		RETURNING "id", "title", "price", "description", "stock", "createdAt", "updatedAt" 
	`

	getProductsQuery = `
		SELECT "id", "title", "price", "description", "stock", "createdAt", "updatedAt"  from "products"
		ORDER BY "id" ASC	
	`
)

type productPG struct {
	db *sql.DB
}

func NewProductPG(db *sql.DB) product_repo.ProductRepo {
	return &productPG{
		db: db,
	}
}

func (p *productPG) GetProducts() ([]*entity.Product, errs.MessageErr) {
	rows, err := p.db.Query(getProductsQuery)

	if err != nil {
		return nil, errs.NewInternalServerError("something went wrong")
	}

	defer rows.Close()

	var products []*entity.Product

	for rows.Next() {
		var product entity.Product

		err = rows.Scan(&product.Id, &product.Title, &product.Price, &product.Description, &product.Stock, &product.CreatedAt, &product.UpdatedAt)

		if err != nil {
			return nil, errs.NewInternalServerError("something went wrong")
		}

		products = append(products, &product)
	}

	return products, nil
}

func (p *productPG) CreateProduct(newProduct entity.Product) (*entity.Product, errs.MessageErr) {

	row := p.db.QueryRow(createProductQuery, newProduct.Title, newProduct.Price, newProduct.Description, newProduct.Stock)

	var product entity.Product

	err := row.Scan(&product.Id, &product.Title, &product.Price, &product.Description, &product.Stock, &product.CreatedAt, &product.UpdatedAt)

	if err != nil {
		return nil, errs.NewInternalServerError("something went wrong")
	}

	return &product, nil
}
