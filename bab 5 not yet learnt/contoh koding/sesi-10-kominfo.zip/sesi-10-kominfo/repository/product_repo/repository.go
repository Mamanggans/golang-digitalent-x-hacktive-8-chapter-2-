package product_repo

import (
	"sesi-10-kominfo/entity"
	"sesi-10-kominfo/pkg/errs"
)

type ProductRepo interface {
	CreateProduct(newProduct entity.Product) (*entity.Product, errs.MessageErr)
	GetProducts() ([]*entity.Product, errs.MessageErr)
}
