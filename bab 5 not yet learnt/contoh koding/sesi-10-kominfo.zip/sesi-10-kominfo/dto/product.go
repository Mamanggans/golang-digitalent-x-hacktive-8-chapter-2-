package dto

import "time"

type NewProductRequest struct {
	Title       string `json:"title" example:"Charger Iphone"`
	Price       int    `json:"price" example:"650000"`
	Description string `json:"description" example:"charger iphone ori ibox"`
	Stock       int    `json:"stock" example:"2000"`
}

type ProductResponse struct {
	Id          int       `json:"id" example:"1"`
	Title       string    `json:"title" example:"Charger Iphone"`
	Description string    `json:"description" example:"charger iphone ori ibox"`
	Price       int       `json:"price" example:"650000"`
	Stock       int       `json:"stock" example:"2000"`
	CreatedAt   time.Time `json:"createdAt" example:"2023-01-01"`
}

type NewProductResponse struct {
	Result     string          `json:"result" example:"success"`
	StatusCode int             `json:"statusCode" example:"201"`
	Messsage   string          `json:"message" example:"product data successfully created"`
	Data       ProductResponse `json:"data"`
}

type ProductsResultResponse struct {
	Result     string            `json:"result" example:"success"`
	StatusCode int               `json:"statusCode" example:"200"`
	Messsage   string            `json:"message" example:"product data successfully sent"`
	Data       []ProductResponse `json:"data"`
}
