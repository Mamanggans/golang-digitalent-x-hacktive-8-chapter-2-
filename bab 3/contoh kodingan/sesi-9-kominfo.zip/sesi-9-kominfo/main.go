package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
)

type Book struct {
	Id     int
	Title  string `json:"judulBuku"`
	Author string `json:"pengarang"`
}

func main() {
	jsonBook :=
		`
		[
			{
				"id": 1,
				"judulBuku": "Filosofi Teras",
				"pengarang" : "Henry Manampiring"
			},
			{
				"id": 2,
				"judulBuku": "Atomic Habbit",
				"pengarang" : "Lupa"
			},
			{
				"id": 3,
				"judulBuku": "The Secret",
				"pengarang" : "Lupa"
			}
		]
	`

	book := []Book{}

	err := json.Unmarshal([]byte(jsonBook), &book)

	if err != nil {
		panic(err.Error())
	}

	bs, err := json.MarshalIndent(book, "", " ")

	if err != nil {
		panic(err.Error())
	}

	err = ioutil.WriteFile("book.json", bs, 0644)

	if err != nil {
		panic(err.Error())
	}

	bookJsonData, err := ioutil.ReadFile("book.json")

	if err != nil {
		panic(err.Error())
	}

	fmt.Println(string(bookJsonData))

	jsonBook2 :=
		`
		{
			"id": 10,
			"title": "Rich Dad, Poor Dad",
			"author": "Robert Kiyosaki"
		}
	`

	bookMap := map[string]interface{}{}

	err = json.Unmarshal([]byte(jsonBook2), &bookMap)

	fmt.Println("bookMap:", bookMap)
}
