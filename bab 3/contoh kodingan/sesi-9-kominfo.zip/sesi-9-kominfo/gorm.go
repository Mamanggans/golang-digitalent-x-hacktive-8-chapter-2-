package main

// import (
// 	"errors"
// 	"fmt"
// 	"log"
// 	"net/http"
// 	"strconv"
// 	"time"

// 	"github.com/gin-gonic/gin"
// 	"gorm.io/driver/postgres"
// 	"gorm.io/gorm"
// )

// const (
// 	host     = "localhost"
// 	password = "postgres"
// 	user     = "airelljordan"
// 	dbname   = "h8-products"
// 	port     = "5432"
// )

// const PORT = ":3000"

// type User struct {
// 	gorm.Model
// 	Email    string `gorm:"unique;not null;type:varchar(191)"`
// 	Products []Product
// }

// func (u *User) BeforeCreate(tx *gorm.DB) (err error) {

// 	fmt.Printf("BeforeCreateUser: %+v \n", *u)
// 	err = errors.New("invalid user")
// 	return
// }

// type Product struct {
// 	ID        uint      `gorm:"primaryKey" json:"id"`
// 	Title     string    `gorm:"not null;type:varchar(191)" json:"title"`
// 	UserID    uint      `json:"user_id"`
// 	CreatedAt time.Time `json:"created_at"`
// 	UpdatedAt time.Time `json:"updated_at"`
// }

// type ProductRequest struct {
// 	Title string `json:"title"`
// }

// var (
// 	db  *gorm.DB
// 	err error
// )

// func init() {

// 	dsn := fmt.Sprintf("host=%s user=%s password=%s dbname=%s port=%s sslmode=disable TimeZone=Asia/Jakarta", host, user, password, dbname, port)
// 	db, err = gorm.Open(postgres.Open(dsn), &gorm.Config{})

// 	if err != nil {
// 		panic(err.Error())
// 	}

// 	// err = db.Debug().AutoMigrate(User{}, Product{})

// 	// if err != nil {
// 	// 	panic(err.Error())
// 	// }
// }

// func main() {
// 	route := gin.Default()

// 	productRoutes := route.Group("/products")
// 	{
// 		productRoutes.POST("/", createProduct)
// 		productRoutes.GET("/", getProducts)
// 		productRoutes.GET("/:productId", getProductById)
// 		productRoutes.PUT("/:productId", updateProduct)
// 		productRoutes.DELETE("/:productId", deleteProduct)

// 		productRoutes.GET("/users", getUserProducts)
// 	}

// 	route.Run(PORT)
// }

// func getUserProducts(c *gin.Context) {

// 	users := []User{}

// 	err = db.Preload("Products").Find(&users).Error

// 	c.JSON(http.StatusOK, users)
// }

// func getProducts(c *gin.Context) {
// 	products := []Product{}

// 	err = db.Find(&products).Error

// 	if err != nil {
// 		c.JSON(http.StatusInternalServerError, gin.H{
// 			"message": "something went wrong",
// 		})
// 		return
// 	}

// 	c.JSON(http.StatusOK, products)
// }

// func getProductById(c *gin.Context) {
// 	productId := c.Param("productId")

// 	parseId, err := strconv.Atoi(productId)

// 	if err != nil {
// 		c.JSON(http.StatusBadRequest, gin.H{
// 			"message": "invalid product id",
// 		})
// 		return
// 	}

// 	product := Product{
// 		ID: uint(parseId),
// 	}

// 	err = db.First(&product).Error

// 	if err != nil {
// 		if err == gorm.ErrRecordNotFound {
// 			c.JSON(http.StatusNotFound, gin.H{
// 				"message": "product not found",
// 			})
// 			return
// 		}

// 		c.JSON(http.StatusInternalServerError, gin.H{
// 			"message": "something went wrong",
// 		})
// 		return
// 	}

// 	c.JSON(http.StatusOK, product)
// }

// func updateProduct(c *gin.Context) {
// 	productId := c.Param("productId")

// 	parseId, err := strconv.Atoi(productId)

// 	if err != nil {
// 		c.JSON(http.StatusBadRequest, gin.H{
// 			"message": "invalid product id",
// 		})
// 		return
// 	}
// 	var productRequest ProductRequest

// 	if err := c.ShouldBindJSON(&productRequest); err != nil {
// 		c.JSON(422, gin.H{
// 			"message": "invalid request body",
// 		})
// 		return
// 	}

// 	product := Product{
// 		ID: uint(parseId),
// 	}

// 	err = db.Model(&product).Updates(Product{Title: productRequest.Title}).Error

// 	if err != nil {
// 		c.JSON(http.StatusInternalServerError, gin.H{
// 			"message": "something went wrong",
// 		})
// 		return
// 	}

// 	c.JSON(http.StatusOK, product)
// }

// func deleteProduct(c *gin.Context) {
// 	productId := c.Param("productId")

// 	parseId, err := strconv.Atoi(productId)

// 	if err != nil {
// 		c.JSON(http.StatusBadRequest, gin.H{
// 			"message": "invalid product id",
// 		})
// 		return
// 	}

// 	err = db.Delete(&Product{}, parseId).Error

// 	if err != nil {
// 		c.JSON(http.StatusInternalServerError, gin.H{
// 			"message": "something went wrong",
// 		})
// 		return
// 	}

// 	c.JSON(http.StatusOK, gin.H{
// 		"message": "Product has been deleted successfully",
// 	})
// }

// func createProduct(c *gin.Context) {
// 	var productRequest ProductRequest

// 	if err := c.ShouldBindJSON(&productRequest); err != nil {
// 		c.JSON(422, gin.H{
// 			"message": "invalid request body",
// 		})
// 		return
// 	}

// 	product := Product{
// 		Title:  productRequest.Title,
// 		UserID: 1,
// 	}

// 	err = db.Create(&product).Error

// 	if err != nil {
// 		c.JSON(500, gin.H{
// 			"message": "something went wrong",
// 		})
// 		return
// 	}

// 	c.JSON(201, product)
// }

// func saveUser(userId uint, newEmail string) {
// 	user := User{}

// 	user.ID = userId

// 	user.Email = newEmail

// 	err = db.Save(&user).Error

// 	if err != nil {
// 		log.Panicf("error saving user: %s \n", err.Error())
// 	}
// }

// func updateUser(userId uint, newEmail string) {
// 	user := User{}

// 	user.ID = userId

// 	err = db.Model(&user).Updates(User{Email: newEmail}).Error

// 	if err != nil {
// 		log.Panicf("error updating user: %s \n", err.Error())
// 	}

// 	fmt.Printf("updated user %+v \n", user)

// }

// func createUser(email string) {
// 	user := User{
// 		Email: email,
// 	}

// 	err = db.Create(&user).Error

// 	if err != nil {
// 		log.Panicf("error creating user %s:", err.Error())
// 	}

// 	fmt.Printf("new user: %+v\n", user)
// }
