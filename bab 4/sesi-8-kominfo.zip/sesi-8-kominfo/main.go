package main

import (
	"database/sql"
	"fmt"
	"log"
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	_ "github.com/lib/pq"
)

const (
	host     = "localhost"
	port     = "5432"
	username = "airelljordan"
	password = "postgres"
	dbname   = "sesi-9-kominfo"
	dialect  = "postgres"
)

type Product struct {
	Id        int       `json:"id"`
	Title     string    `json:"title"`
	Price     int       `json:"price"`
	CreatedAt time.Time `json:"createdAt"`
	UpdatedAt time.Time `json:"updatedAt"`
}

type ProductRequest struct {
	Title string `json:"title"`
	Price int    `json:"price"`
}

var (
	db  *sql.DB
	err error
)

const PORT = ":4000"

func init() {
	psqlInfo := fmt.Sprintf("host=%s port=%s user=%s password=%s dbname=%s sslmode=disable", host, port, username, password, dbname)

	db, err = sql.Open(dialect, psqlInfo)

	if err != nil {
		log.Panicf("error while connecting to db: %s", err.Error())
	}

	err = db.Ping()

	if err != nil {
		log.Panicf("error while verifying the connection to db: %s", err.Error())
	}

	_ = db

	createProductTableQuery :=
		`
		CREATE TABLE IF NOT EXISTS "products" (
			id SERIAL PRIMARY KEY,
			title varchar(255) NOT NULL,
			price int NOT NULL,
			createdAt timestamptz DEFAULT now(),
			updatedAt timestamptz DEFAULT now()
		);
	`

	_, err = db.Exec(createProductTableQuery)

	if err != nil {
		log.Panicf("error while creating Products table: %s", err.Error())
	}

	fmt.Println("Sukses")
}

func main() {
	route := gin.Default()

	route.GET("/products", getProducts)

	route.POST("/products", createProduct)

	route.PUT("/products/:productId", updateProductById)

	route.GET("/products/:productId", getOneProduct)

	route.Run(PORT)
}

func getProducts(ctx *gin.Context) {
	getProductsQuery :=
		`
		SELECT id, title, price, createdAt, updatedAt from "products"
	`

	rows, err := db.Query(getProductsQuery)

	if err != nil {
		log.Panicf("error occured while getting product data: %s \n", err.Error())
	}

	defer rows.Close()

	products := []Product{}

	for rows.Next() {
		var product Product

		err = rows.Scan(&product.Id, &product.Title, &product.Price, &product.CreatedAt, &product.UpdatedAt)

		if err != nil {
			log.Panicf("error occured while scanning product data: %s \n", err.Error())
		}

		products = append(products, product)

	}

	ctx.JSON(http.StatusOK, products)
}

func updateProductById(ctx *gin.Context) {
	id := ctx.Param("productId")

	idResult, err := strconv.Atoi(id)

	if err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, gin.H{
			"message": "invalid id",
		})
		return
	}

	var productRequest ProductRequest

	if err = ctx.ShouldBindJSON(&productRequest); err != nil {
		ctx.AbortWithStatusJSON(http.StatusUnprocessableEntity, gin.H{
			"message": "invalid request body",
		})
		return
	}

	updateProductQuery :=
		`
		UPDATE "products"
		SET title = $2,
		price = $3,
		updatedAt = $4
		WHERE id = $1
		RETURNING id
	`

	row := db.QueryRow(updateProductQuery, idResult, productRequest.Title, productRequest.Price, time.Now())

	var productId int

	err = row.Scan(&productId)

	if err != nil {
		if err == sql.ErrNoRows {
			ctx.AbortWithStatusJSON(http.StatusNotFound, gin.H{
				"message": "product data not found",
			})
			return
		}
		ctx.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{
			"message": "something went wrong",
		})
		return
	}

	message := fmt.Sprintf("product with id %d has been successfully updated", productId)

	ctx.JSON(http.StatusOK, gin.H{
		"message": message,
	})
}

func getOneProduct(ctx *gin.Context) {

	id := ctx.Param("productId")

	idResult, err := strconv.Atoi(id)

	if err != nil {
		ctx.AbortWithStatusJSON(http.StatusBadRequest, gin.H{
			"message": "invalid id",
		})
		return
	}

	getOneProductQuery :=
		`
		SELECT id, title, price, createdAt, updatedAt FROM "products" 
		WHERE id = $1;
	`

	var product Product

	row := db.QueryRow(getOneProductQuery, idResult)

	err = row.Scan(&product.Id, &product.Title, &product.Price, &product.CreatedAt, &product.UpdatedAt)

	if err != nil {
		if err == sql.ErrNoRows {
			ctx.AbortWithStatusJSON(http.StatusNotFound, gin.H{
				"message": "product data not found",
			})
			return
		}
		ctx.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{
			"message": "something went wrong",
		})
		return
	}

	ctx.JSON(http.StatusOK, product)
}

func createProduct(ctx *gin.Context) {
	var productRequest ProductRequest

	if err := ctx.ShouldBindJSON(&productRequest); err != nil {
		ctx.AbortWithStatusJSON(http.StatusUnprocessableEntity, gin.H{
			"messsage": "invalid request body",
		})
		return
	}

	createProductQuery :=
		`
		INSERT INTO "products"
		(
			title,
			price
		)
		VALUES($1, $2)
		RETURNING title, id, price, createdAt, updatedAt
	`

	row := db.QueryRow(createProductQuery, productRequest.Title, productRequest.Price)

	var newProduct Product

	err = row.Scan(&newProduct.Title, &newProduct.Id, &newProduct.Price, &newProduct.CreatedAt, &newProduct.UpdatedAt)

	if err != nil {
		log.Panicf("error while creating new product data: %s \n", err.Error())
	}

	ctx.JSON(http.StatusCreated, newProduct)
}
